"""LLM Questions programme"""

import os
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI


def _load_api_key() -> str:
    """
    Load API key from environment first, then from local env files.
    Supported files: API.env, .env (in the same directory as this file).
    """
    base_dir = Path(__file__).resolve().parent
    load_dotenv(base_dir / "API.env")
    load_dotenv(base_dir / ".env")

    api_key = os.getenv("AZURE_API_KEY")
    if not api_key:
        raise RuntimeError(
            "AZURE_API_KEY not found. Please set it in system environment, "
            "or add it to API.env/.env in the project directory."
        )
    return api_key


AZURE_API_KEY = _load_api_key()

# EUS2 uses an OpenAI-compatible /v1 endpoint
EUS2_BASE_URL = "https://cuhk-apip.azure-api.net/openai-eus2/openai/v1"

# Initialize the client with the EUS2 base URL (30s timeout aligns with Game loading retry UX)
client = OpenAI(
    base_url=EUS2_BASE_URL,
    api_key=AZURE_API_KEY,
    default_headers={"api-key": AZURE_API_KEY},
    timeout=30.0,
)

def q_generate(prompt: str) -> str:
        response = client.chat.completions.create(
            model="gpt-5.1",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            temperature=0.7,  # Control response creativity (0-1)
        )
        return response.choices[0].message.content


prompt = """\
    Please generate trivia content for a Jeopardy-style game in THREE rounds.

    Rounds 1 and 2 (full boards):\
    6 categories: "Science", "History", "Literature", "Geography", "Film", "Math".\
    Each category has exactly 5 questions.\
    Each question has 3 short answer options (do not prefix with "what is") and "correct" as the 0-based index.\
    Round 1 question values per category must be exactly 200, 400, 600, 800, 1000 (easiest at 200).\
    Round 2 question values must be EXACTLY DOUBLE of Round 1 values at the same row position: 400, 800, 1200, 1600, 2000.\
    Overall difficulty: round1 ≈ 2/10, round2 ≈ 6/10.

    Round 3 (Final Jeopardy — NOT a full board):\
    Generate EXACTLY ONE category and EXACTLY ONE question inside it.\
    Pick one category name at random from the five above (or use that name as "name").\
    Use a single high-stakes "value" for that one question (e.g. 2000). Difficulty ≈ 10/10.\
    Same 3-option format as other rounds.

    Output: one JSON object only (no markdown, no commentary). Keys: "round1", "round2", "round3".
    - round1 and round2: array of 5 objects, each { "name": "<category>", "questions": [ ... 5 question objects ... ] }.
    - round3: array of ONE object only: { "name": "<chosen category>", "questions": [ ONE question object ] }.

    Each question object shape:
    { "value": <int>, "question": "<clue text>", "options": ["...", "...", "..."], "correct": <0|1|2> }
    """

if __name__ == "__main__":
    data = q_generate(prompt)
    print(data)