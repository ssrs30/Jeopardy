import pygame
from pathlib import Path

pygame.init()

class loading:

    def __init__(self, screen):
        self.screen = screen
        
        base_dir = Path(__file__).resolve().parent.parent
        loading1_path = base_dir / "Game Assets" / "LOADING1.png"
        loading2_path = base_dir / "Game Assets" / "LOADING2.png"
        loading3_path = base_dir / "Game Assets" / "LOADING3.png"
        continue_img = base_dir / "Game Assets" / "CONTINUE.png"
        button = base_dir / "Game Assets" / "button.png"
        button_pressed = base_dir / "Game Assets" / "button_pressed.png"

        loading1 = pygame.image.load(str(loading1_path)).convert_alpha()
        loading2 = pygame.image.load(str(loading2_path)).convert_alpha()
        loading3 = pygame.image.load(str(loading3_path)).convert_alpha()
        self.continue_img = pygame.image.load(str(continue_img)).convert_alpha()
        self.loading = [loading1, loading2, loading3]
        self.loading_rect = loading1.get_rect(center = (600, 400))
        self.default_center = (600, 400)
        self.button = pygame.image.load(str(button)).convert_alpha()
        self.button_pressed = pygame.image.load(str(button_pressed)).convert_alpha()
        self.button_rect = self.button.get_rect(center = (600, 400))

        self.current_frame = 0
        self.last_update = pygame.time.get_ticks()
        self.animation_speed = 500  # Milliseconds between image swaps
        self._hint_font = pygame.font.Font(None, 30)

    def update(self, events, data_ready, generation_failed: bool = False) -> int:
        """handle clicks and hover"""
        mouse_pos = pygame.mouse.get_pos()
        if generation_failed:
            now = pygame.time.get_ticks()
            if now - self.last_update > self.animation_speed:
                self.last_update = now
                self.current_frame = (self.current_frame + 1) % len(self.loading)
            self.current_img = self.loading[self.current_frame]
            self.loading_rect = self.current_img.get_rect(center=self.default_center)
            self.current_button = pygame.Surface((200, 54))
            for event in events:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                    return 6
            return 5

        if not data_ready:
            now = pygame.time.get_ticks()
            if now - self.last_update > self.animation_speed:
                self.last_update = now
                self.current_frame = (self.current_frame + 1) % len(self.loading)

            self.current_img = self.loading[self.current_frame]
            self.loading_rect = self.current_img.get_rect(center=self.default_center)
            self.current_button = pygame.Surface((200, 54))
        else:
            self.current_img = self.continue_img
            self.loading_rect = self.continue_img.get_rect(center=self.default_center)

            if self.button_rect.collidepoint(mouse_pos):
                self.current_button = self.button_pressed
            else:
                self.current_button = self.button

            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.button_rect.collidepoint(event.pos):
                        return 1

        return 5

    def draw(self, generation_failed: bool = False):
        self.screen.fill((0, 0, 0))
        self.screen.blit(self.current_button, self.button_rect)
        self.screen.blit(self.current_img, self.loading_rect)
        if generation_failed:
            title = self._hint_font.render("Restart", True, (255, 90, 90))
            hint = self._hint_font.render("Press R to reload", True, (230, 230, 230))
            tr = title.get_rect(center=(600, 720))
            hr = hint.get_rect(center=(600, 755))
            self.screen.blit(title, tr)
            self.screen.blit(hint, hr)
        
