import pygame
from pathlib import Path

pygame.init()


class pause_window:

    def __init__(self, screen):
        self.screen = screen
        base_dir = Path(__file__).resolve().parent.parent
        quit_frame_path = base_dir / "Game Assets" / "quit_frame.png"
        quitting_path = base_dir / "Game Assets" / "QUITTING.png"
        button_path = base_dir / "Game Assets" / "button.png"
        button_pressed_path = base_dir / "Game Assets" / "button_pressed.png"
        yes_path = base_dir / "Game Assets" / "YES.png"
        no_path = base_dir / "Game Assets" / "NO.png"
        quit_button_path = base_dir / "Game Assets" / "quit_button.png"
        button_sound_path = base_dir / "Sound Effect" / "button.mp3"
        self.button_sound = pygame.mixer.Sound(button_sound_path)

        self.dark_surface = pygame.Surface((1200, 800))
        self.dark_surface.fill((0, 0, 0))
        self.dark_surface.set_alpha(128)
        self.quit_frame = pygame.image.load(str(quit_frame_path)).convert_alpha()
        self.quitting = pygame.image.load(str(quitting_path)).convert_alpha()
        self.yes = pygame.image.load(str(yes_path)).convert_alpha()
        self.no = pygame.image.load(str(no_path)).convert_alpha()
        self.button = pygame.image.load(str(button_path)).convert_alpha()
        self.button_pressed = pygame.image.load(str(button_pressed_path)).convert_alpha()
        self.buttonL_rect = self.button.get_rect(topleft=(360, 400))
        self.buttonR_rect = self.button.get_rect(topleft=(640, 400))
        self.current_buttonL = self.button
        self.current_buttonR = self.button
        self.quit_button = pygame.image.load(str(quit_button_path)).convert_alpha()
        self.quit_button_rect = self.quit_button.get_rect(topright=(1190, 10))

    def update(self, events, num) -> int:
        """Handle clicks and hover."""
        mouse_pos = pygame.mouse.get_pos()
        self.current_buttonL = self.button_pressed if self.buttonL_rect.collidepoint(mouse_pos) else self.button
        self.current_buttonR = self.button_pressed if self.buttonR_rect.collidepoint(mouse_pos) else self.button
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.buttonL_rect.collidepoint(event.pos):
                    return 0
                if self.buttonR_rect.collidepoint(event.pos) or self.quit_button_rect.collidepoint(event.pos):
                    self.button_sound.play()
                    return num
        return 2

    def draw(self):
        self.screen.blit(self.dark_surface, (0, 0))
        self.screen.blit(self.quit_button, self.quit_button_rect)
        self.screen.blit(self.quit_frame, (300, 250))
        self.screen.blit(self.quitting, (400, 310))
        self.screen.blit(self.current_buttonL, self.buttonL_rect)
        self.screen.blit(self.yes, (420, 405))
        self.screen.blit(self.current_buttonR, self.buttonR_rect)
        self.screen.blit(self.no, (710, 405))
