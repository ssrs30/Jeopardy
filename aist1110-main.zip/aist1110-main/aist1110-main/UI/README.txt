Start the game by running "main.py"

UI sources:
https://chottoinc.itch.io/rustic-ui-pixel-art?download
https://pixel-boy.itch.io/icon-godot-node
https://limezu.itch.io/moderninteriors
https://danieldiggle.itch.io/sunnyside?download
https://pngtree.com/free-backgrounds-photos/pixel-piano?pattern=horizontal
https://pixabay.com/sound-effects/search/game/
https://www.dafont.com/pix32.font