import pygame
import pygame.freetype
from pathlib import Path

pygame.init()
pygame.font.init()


class power_ups:
    """shoppable item"""

    def __init__(
        self,
        item_no: int,
        name: str,
        price: int,
        icon: pygame.Surface,
        frame_rect: pygame.Rect,
        icon_topleft: tuple[int, int],
        price_text_pos: tuple[int, int],
        name_text_pos: tuple[int, int],
    ):
        self.item_no = item_no
        self.name = name
        self.price = price
        self.icon = icon
        self.frame_rect = frame_rect
        self.icon_topleft = icon_topleft
        self.price_text_pos = price_text_pos
        self.name_text_pos = name_text_pos

    def try_purchase(self, shop: "Shop") -> None:
        if shop.coin > 0:
            shop.buy_sound.play()
            shop._show_text(f"Item {self.name} purchased!")
            shop.coin -= self.price
            shop.purchased_item_no = self.item_no
        else:
            shop._show_text("Not enough coins!")


class SkipPowerUp(power_ups):
    def __init__(self, icon: pygame.Surface, frame_rect: pygame.Rect):
        super().__init__(
            item_no=1,
            name="Skips",
            price=500,
            icon=icon,
            frame_rect=frame_rect,
            icon_topleft=(240, 340),
            price_text_pos=(390, 370),
            name_text_pos=(370, 330),
        )


class FiftyFiftyPowerUp(power_ups):
    def __init__(self, icon: pygame.Surface, frame_rect: pygame.Rect):
        super().__init__(
            item_no=2,
            name="Fifty-fifty",
            price=500,
            icon=icon,
            frame_rect=frame_rect,
            icon_topleft=(690, 340),
            price_text_pos=(840, 370),
            name_text_pos=(790, 330),
        )


class DoubleAwardPowerUp(power_ups):
    def __init__(self, icon: pygame.Surface, frame_rect: pygame.Rect):
        super().__init__(
            item_no=3,
            name="Double award",
            price=500,
            icon=icon,
            frame_rect=frame_rect,
            icon_topleft=(240, 540),
            price_text_pos=(390, 570),
            name_text_pos=(330, 530),
        )


class ShieldPowerUp(power_ups):
    def __init__(self, icon: pygame.Surface, frame_rect: pygame.Rect):
        super().__init__(
            item_no=4,
            name="Shield",
            price=500,
            icon=icon,
            frame_rect=frame_rect,
            icon_topleft=(690, 543),
            price_text_pos=(840, 570),
            name_text_pos=(820, 530),
        )


class Shop:
    """Shop screen"""

    def __init__(self, screen):
        self.screen = screen

        current_dir = Path(__file__).parent
        frame_path = current_dir / "Game Assets" / "frame_player.png"
        frame_pressed_path = current_dir / "Game Assets" / "frame_player_pressed.png"
        shop_title_path = current_dir / "Game Assets" / "SHOP_title.png"
        frame_return_path = current_dir / "Game Assets" / "button.png"
        frame_return_pressed_path = current_dir / "Game Assets" / "button_pressed.png"
        return_text_path = current_dir / "Game Assets" / "RETURN.png"
        return_pressed_path = current_dir / "Game Assets" / "RETURN_pressed.png"
        quit_button_path = current_dir / "Game Assets" / "quit_button.png"
        items_path = current_dir / "Game Assets" / "ITEMS.png"
        items_pressed_path = current_dir / "Game Assets" / "ITEMS_pressed.png"
        shop_path = current_dir / "Game Assets" / "SHOP.png"
        shop_pressed_path = current_dir / "Game Assets" / "SHOP_pressed.png"
        top_button_path = current_dir / "Game Assets" / "top_button.png"
        top_button_pressed_path = current_dir / "Game Assets" / "top_button_pressed.png"
        icon1_path = current_dir / "Game Assets" / "shop_icon1.png"
        icon2_path = current_dir / "Game Assets" / "shop_icon2.png"
        icon3_path = current_dir / "Game Assets" / "shop_icon3.png"
        icon4_path = current_dir / "Game Assets" / "shop_icon4.png"

        self.buy_sound_path = current_dir / "Sound Effect" / "buy_item.mp3"
        self.buy_sound = pygame.mixer.Sound(self.buy_sound_path)
        self.button_sound_path = current_dir / "Sound Effect" / "button.mp3"
        self.button_sound = pygame.mixer.Sound(self.button_sound_path)

        self.frame = pygame.image.load(str(frame_path)).convert_alpha()
        self.frame_pressed = pygame.image.load(str(frame_pressed_path)).convert_alpha()
        self.frame_rect1 = self.frame.get_rect(topleft=(200, 300))
        self.frame_rect2 = self.frame.get_rect(topleft=(650, 300))
        self.frame_rect3 = self.frame.get_rect(topleft=(200, 500))
        self.frame_rect4 = self.frame.get_rect(topleft=(650, 500))
        self.shop_title = pygame.image.load(str(shop_title_path)).convert_alpha()

        self.quit_button = pygame.image.load(str(quit_button_path)).convert_alpha()
        self.quit_button_rect = self.quit_button.get_rect(topright=(1190, 10))

        self.frame_return = pygame.image.load(str(frame_return_path)).convert_alpha()
        self.frame_return_pressed = pygame.image.load(str(frame_return_pressed_path)).convert_alpha()
        self.frame_return_rect = self.frame_return.get_rect(center=(600, 700))

        self.return_text = pygame.image.load(str(return_text_path)).convert_alpha()
        self.return_pressed = pygame.image.load(str(return_pressed_path)).convert_alpha()
        self.return_rect = self.return_text.get_rect(center=(600, 700))

        self.items = pygame.image.load(str(items_path)).convert_alpha()
        self.items_pressed = pygame.image.load(str(items_pressed_path)).convert_alpha()
        self.items_rect = self.items.get_rect(center=(1050, 50))

        self.shop = pygame.image.load(str(shop_path)).convert_alpha()
        self.shop_pressed = pygame.image.load(str(shop_pressed_path)).convert_alpha()
        self.shop_rect = self.shop.get_rect(center=(875, 50))

        self.top_button = pygame.image.load(str(top_button_path)).convert_alpha()
        self.top_button_pressed = pygame.image.load(str(top_button_pressed_path)).convert_alpha()
        self.top_button_items_rect = self.top_button.get_rect(center=(1050, 50))
        self.top_button_shop_rect = self.top_button.get_rect(center=(875, 50))

        self.icon1 = pygame.image.load(str(icon1_path)).convert_alpha()
        self.icon2 = pygame.image.load(str(icon2_path)).convert_alpha()
        self.icon3 = pygame.image.load(str(icon3_path)).convert_alpha()
        self.icon4 = pygame.image.load(str(icon4_path)).convert_alpha()

        self.font = pygame.freetype.Font(current_dir / "Pix32.ttf", 30)

        self.power_slots: tuple[power_ups, ...] = (
            SkipPowerUp(self.icon1, self.frame_rect1),
            FiftyFiftyPowerUp(self.icon2, self.frame_rect2),
            DoubleAwardPowerUp(self.icon3, self.frame_rect3),
            ShieldPowerUp(self.icon4, self.frame_rect4),
        )
        self._sync_legacy_power_attrs()

        self.coin = 2000
        self.text = ""
        self.text_shown_at_ms = 0
        self.text_duration_ms = 3000
        self.purchased_item_no = 0

    def _sync_legacy_power_attrs(self) -> None:
        """keep icon number, name, and rects in sync with power slots"""
        for i, slot in enumerate(self.power_slots, start=1):
            setattr(self, f"icon{i}", slot.icon)
            setattr(self, f"icon{i}_no", slot.price)
            setattr(self, f"icon{i}_name", slot.name)
            setattr(self, f"frame_rect{i}", slot.frame_rect)

    def _show_text(self, msg: str):
        self.text = msg
        self.text_shown_at_ms = pygame.time.get_ticks()

    def pop_purchased_item(self) -> int:
        """Return last purchased item id"""
        item_no = self.purchased_item_no
        self.purchased_item_no = 0
        return item_no

    def update(self, events):
        """Handle clicks and hover."""
        mouse_pos = pygame.mouse.get_pos()

        if self.frame_return_rect.collidepoint(mouse_pos):
            self.current_button = self.frame_return_pressed
            self.current_return = self.return_pressed
        else:
            self.current_button = self.frame_return
            self.current_return = self.return_text

        if self.top_button_items_rect.collidepoint(mouse_pos):
            self.current_top_button_items = self.top_button_pressed
            self.current_items = self.items_pressed
        else:
            self.current_top_button_items = self.top_button
            self.current_items = self.items

        self.current_frame1 = (
            self.frame_pressed if self.power_slots[0].frame_rect.collidepoint(mouse_pos) else self.frame
        )
        self.current_frame2 = (
            self.frame_pressed if self.power_slots[1].frame_rect.collidepoint(mouse_pos) else self.frame
        )
        self.current_frame3 = (
            self.frame_pressed if self.power_slots[2].frame_rect.collidepoint(mouse_pos) else self.frame
        )
        self.current_frame4 = (
            self.frame_pressed if self.power_slots[3].frame_rect.collidepoint(mouse_pos) else self.frame
        )

        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.frame_return_rect.collidepoint(event.pos):
                    self.button_sound.play()
                    return 6
                if self.top_button_items_rect.collidepoint(event.pos):
                    self.button_sound.play()
                    return 11
                if self.quit_button_rect.collidepoint(event.pos):
                    self.button_sound.play()
                    return 2
                for slot in self.power_slots:
                    if slot.frame_rect.collidepoint(event.pos):
                        slot.try_purchase(self)
                        break

        return 10

    def draw(self):
        self.screen.fill((0, 0, 0))

        self.screen.blit(self.quit_button, self.quit_button_rect)
        self.screen.blit(self.current_top_button_items, self.top_button_items_rect)
        self.screen.blit(self.top_button_pressed, self.top_button_shop_rect)
        self.screen.blit(self.current_items, self.items_rect)
        self.screen.blit(self.shop_pressed, self.shop_rect)
        self.screen.blit(self.current_button, self.frame_return_rect)
        self.screen.blit(self.current_return, self.return_rect)

        self.screen.blit(self.shop_title, (400, 100))

        self.screen.blit(self.current_frame1, self.frame_rect1)
        self.screen.blit(self.current_frame2, self.frame_rect2)
        self.screen.blit(self.current_frame3, self.frame_rect3)
        self.screen.blit(self.current_frame4, self.frame_rect4)

        for slot in self.power_slots:
            self.screen.blit(slot.icon, slot.icon_topleft)
            self.font.render_to(
                self.screen, slot.price_text_pos, str(slot.price), (255, 255, 255)
            )
            self.font.render_to(self.screen, slot.name_text_pos, str(slot.name), (255, 255, 255))

        self.font.render_to(self.screen, (100, 100), "Coins: " + str(self.coin), (255, 255, 255))

        if self.text and pygame.time.get_ticks() - self.text_shown_at_ms <= self.text_duration_ms:
            self.text_surf, self.text_rect = self.font.render(self.text, (255, 255, 255))
            self.text_rect.center = (600, 750)
            self.screen.blit(self.text_surf, self.text_rect)


if __name__ == "__main__":
    screen = pygame.display.set_mode((1200, 800))
    window = Shop(screen)
    clock = pygame.time.Clock()
    num = 10
    running = True

    while running:
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                running = False

        if num == 10:
            num = window.update(events)
            window.draw()

        pygame.display.flip()
        clock.tick(30)

    pygame.quit()
