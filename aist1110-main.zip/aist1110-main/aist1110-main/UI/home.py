import pygame
from pathlib import Path

pygame.init()
pygame.font.init()
pygame.mixer.init()


class Homepage:

    def __init__(self, screen):
        self.screen = screen
        ui_dir = Path(__file__).resolve().parent
        base_dir = ui_dir.parent
        bg_path = base_dir / "Game Assets" / "bg.png"
        title_path = base_dir / "Game Assets" / "JEOPARDY.png"
        start_path = base_dir / "Game Assets" / "START.png"
        startframe_path = base_dir / "Game Assets" / "frame_start.png"
        start_pressed_path = base_dir / "Game Assets" / "START_hover.png"
        startframe_pressed_path = base_dir / "Game Assets" / "frame_start_hover.png"
        quit_button_path = base_dir / "Game Assets" / "quit_button.png"
        help_path = ui_dir / "Game Assets" / "HELP.png"
        help_pressed_path = ui_dir / "Game Assets" / "HELP_pressed.png"
        if not help_path.exists():
            help_path = base_dir / "Game Assets" / "HELP.png"
        if not help_pressed_path.exists():
            help_pressed_path = base_dir / "Game Assets" / "HELP_pressed.png"
        button_path = base_dir / "Game Assets" / "button.png"
        button_pressed_path = base_dir / "Game Assets" / "button_pressed.png"
        self.menu_BGM_path = base_dir / "Sound Effect" / "menu_BGM.mp3"
        button_sound_path = base_dir / "Sound Effect" / "button.mp3"
        self.button_sound = pygame.mixer.Sound(button_sound_path)

        def _safe_load(path: Path, size=(240, 80), label="MISSING"):
            """Load image"""
            try:
                return pygame.image.load(str(path)).convert_alpha()
            except Exception:
                surf = pygame.Surface(size, pygame.SRCALPHA)
                surf.fill((90, 90, 90))
                pygame.draw.rect(surf, (200, 200, 200), surf.get_rect(), 2)
                font = pygame.font.Font(None, 32)
                txt = font.render(label, True, (255, 255, 255))
                txt_rect = txt.get_rect(center=surf.get_rect().center)
                surf.blit(txt, txt_rect)
                return surf

        self.bg = _safe_load(bg_path, size=(1200, 800), label="BG")
        self.title = _safe_load(title_path, size=(840, 160), label="TITLE")
        self.quit_button = _safe_load(quit_button_path, size=(48, 48), label="X")
        self.quit_button_rect = self.quit_button.get_rect(topright=(1190, 10))
        self.start = _safe_load(start_path, size=(220, 70), label="START")
        self.start_pressed = _safe_load(start_pressed_path, size=(220, 70), label="START")
        self.start_rect = self.start.get_rect(center=(600, 496))
        self.startframe = _safe_load(startframe_path, size=(280, 92), label="")
        self.startframe_pressed = _safe_load(startframe_pressed_path, size=(280, 92), label="")
        self.startframe_rect = self.startframe.get_rect(center=(600, 496))
        self.music_started = False
        self.currentframe_start = self.startframe
        self.current_start = self.start
        self.help = _safe_load(help_path, size=(220, 70), label="HELP")
        self.help_pressed = _safe_load(help_pressed_path, size=(220, 70), label="HELP")
        self.help_rect = self.help.get_rect(center=(600, 650))
        self.button = _safe_load(button_path, size=(280, 92), label="")
        self.button_pressed = _safe_load(button_pressed_path, size=(280, 92), label="")
        self.button_rect = self.button.get_rect(center=(600, 650))

    def update(self, events) -> int:
        """Handle clicks and hover."""
        if not self.music_started:
            pygame.mixer.music.set_volume(0.3)
            pygame.mixer.music.load(self.menu_BGM_path)
            pygame.mixer.music.play(-1)
            self.music_started = True
        mouse_pos = pygame.mouse.get_pos()
        if self.startframe_rect.collidepoint(mouse_pos):
            self.currentframe_start = self.startframe_pressed
            self.current_start = self.start_pressed
        else:
            self.currentframe_start = self.startframe
            self.current_start = self.start
        if self.button_rect.collidepoint(mouse_pos):
            self.current_button = self.button_pressed
            self.current_help = self.help_pressed
        else:
            self.current_button = self.button
            self.current_help = self.help

        for event in events:
            if event.type == pygame.QUIT:
                return 2
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.quit_button_rect.collidepoint(event.pos):
                    self.button_sound.play()
                    self.music_started = False
                    return 2
                if self.startframe_rect.collidepoint(event.pos):
                    self.button_sound.play()
                    self.music_started = False
                    return 3
                if self.button_rect.collidepoint(event.pos):
                    self.button_sound.play()
                    return 4
        return 1

    def draw(self):
        self.screen.blit(self.bg, (0, 0))
        self.screen.blit(self.currentframe_start, self.startframe_rect)
        self.screen.blit(self.current_button, self.button_rect)
        self.screen.blit(self.title, (180, 200))
        self.screen.blit(self.current_start, self.start_rect)
        self.screen.blit(self.current_help, self.help_rect)
        self.screen.blit(self.quit_button, self.quit_button_rect)

if __name__ == "__main__":
    screen = pygame.display.set_mode((1200, 800))
    window = Homepage(screen)
    clock = pygame.time.Clock()
    num = 1
    running = True

    while running:
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                running = False
        
        if num == 1:
            num = window.update(events)
            window.draw()
        
        pygame.display.flip()
        clock.tick(30)
    
    pygame.quit()